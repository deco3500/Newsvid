package com.example.android.a35phototype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button login,sign;
EditText loginame,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login=(Button)findViewById(R.id.login);
        sign=(Button)findViewById(R.id.sign);
        loginame=(EditText)findViewById(R.id.loginame) ;
        password=(EditText)findViewById(R.id.password);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(loginame.getText().toString().equals("user")&&password.getText().toString().equals("user")){

                    Intent inputdata = new Intent(MainActivity.this, userinterface.class);
                    startActivity(inputdata);
                }else {

                    Toast.makeText(getApplicationContext(), "The username and password you entered did not match our records. Please double-check and try again.", Toast.LENGTH_LONG).show();
                }

            }
        });
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inputdata3=new Intent(MainActivity.this,signup.class);
                startActivity(inputdata3);

            }
        });
    }
}
