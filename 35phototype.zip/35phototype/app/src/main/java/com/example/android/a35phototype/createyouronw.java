package com.example.android.a35phototype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class createyouronw extends AppCompatActivity {
ImageView click;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createyouronw);
        click=(ImageView)findViewById(R.id.click);
        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inputdata=new Intent(createyouronw.this,editviode.class);
                startActivity(inputdata);

            }
        });
    }
}
