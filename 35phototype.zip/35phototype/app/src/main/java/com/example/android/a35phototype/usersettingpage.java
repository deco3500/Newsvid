package com.example.android.a35phototype;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class usersettingpage extends AppCompatActivity {
Spinner contuC;
    Spinner contuB;
    ArrayAdapter<CharSequence> adapterC;
    ArrayAdapter<CharSequence> adapterB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usersettingpage);
        contuC=(Spinner)findViewById(R.id.spinnerC);
        contuB=(Spinner)findViewById(R.id.contuB);
                adapterC= ArrayAdapter.createFromResource(this,R.array.countrylist,android.R.layout.simple_spinner_item);
        adapterB= ArrayAdapter.createFromResource(this,R.array.joblist,android.R.layout.simple_spinner_item);

        adapterB.setDropDownViewResource(android.R.layout.simple_spinner_item);
        contuC.setAdapter(adapterC);
        contuB.setAdapter(adapterB);
    }
}
