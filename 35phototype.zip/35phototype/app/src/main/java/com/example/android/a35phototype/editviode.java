package com.example.android.a35phototype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class editviode extends AppCompatActivity {
ImageView video2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editviode);
        video2=(ImageView) findViewById(R.id.video2);

        video2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inputdata=new Intent(editviode.this,personalnew.class);
                startActivity(inputdata);

            }
        });
    }
}
