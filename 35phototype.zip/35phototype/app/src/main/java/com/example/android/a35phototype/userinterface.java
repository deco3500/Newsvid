package com.example.android.a35phototype;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class userinterface extends AppCompatActivity {
ImageView imageView2;
    Spinner spinner1;
    Button pnews,cnews,setting;
    ArrayAdapter<CharSequence> adapter1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinterface);
        imageView2=(ImageView)findViewById(R.id.imageView2);
        spinner1=(Spinner)findViewById(R.id.spinner1);
        pnews=(Button)findViewById(R.id.pnews);

        setting=(Button)findViewById(R.id.setting);

        adapter1= ArrayAdapter.createFromResource(this,R.array.benchmark_list,android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner1.setAdapter(adapter1);

        pnews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent inputdata = new Intent(userinterface.this, personalnew.class);
                startActivity(inputdata);


            }
        });



        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inputdata = new Intent(userinterface.this, usersettingpage.class);
                startActivity(inputdata);



            }
        });




        imageView2.setOnClickListener(new View.OnClickListener() {
            EditText comment;
            @Override
            public void onClick(View view) {
                View view2= LayoutInflater.from(userinterface.this).inflate(R.layout.mbox,null);
                comment=(EditText)view2.findViewById(R.id.comment);
                AlertDialog.Builder builder=new AlertDialog.Builder(userinterface.this);
                builder.setMessage("Comment").setView(view2).setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {



                    }
                }).setNegativeButton("Cancel",null).setCancelable(false);

                AlertDialog alert=builder.create();
                alert.show();

            }
        });
    }
}
