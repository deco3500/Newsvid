package com.example.android.a35phototype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;

public class personalnew extends AppCompatActivity {

    Button tvnews,ynews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personalnew);
        tvnews=(Button)findViewById(R.id.tvnews);
        ynews=(Button)findViewById(R.id.ynews);
        tvnews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent inputdata1 = new Intent(personalnew.this, userinterface.class);
                startActivity(inputdata1);

            }
        });

        ynews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inputdata2 = new Intent(personalnew.this, createyouronw.class);
                startActivity(inputdata2);

            }
        });


    }
}
